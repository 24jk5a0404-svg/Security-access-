const $ = (id) => document.getElementById(id);
let currentUser = null;
async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options });
  const type = response.headers.get("content-type") || "";
  const body = type.includes("application/json") ? await response.json() : await response.text();
  if (!response.ok) throw new Error(body.error || "Request failed");
  return body;
}
function message(text, kind = "") { $("message").textContent = text; $("message").className = kind; }
function showSignedIn(user) {
  currentUser = user;
  $("authPanel").classList.add("hidden");
  $("appPanel").classList.remove("hidden");
  $("status").textContent = `${user.username} · ${user.role}`;
  $("whoami").textContent = `Signed in as ${user.username}. Role: ${user.role}.`;
  $("uploadPanel").classList.toggle("hidden", !["admin","editor"].includes(user.role));
  $("permissionPanel").classList.toggle("hidden", user.role !== "admin");
  $("auditPanel").classList.toggle("hidden", user.role !== "admin");
  loadDocuments();
  if (user.role === "admin") loadAudit();
}
function showSignedOut() {
  currentUser = null;
  $("authPanel").classList.remove("hidden");
  $("appPanel").classList.add("hidden");
  $("status").textContent = "Signed out";
}
async function loadDocuments() {
  try {
    const data = await api("/api/documents");
    const target = $("documents"); target.replaceChildren();
    if (!data.documents.length) { target.textContent = "No documents available to you yet."; return; }
    for (const doc of data.documents) {
      const row = document.createElement("div"); row.className = "doc";
      const info = document.createElement("div");
      const name = document.createElement("strong"); name.textContent = doc.name;
      const meta = document.createElement("small"); meta.textContent = `ID ${doc.id} · ${Math.ceil(doc.size/1024)} KB · ${doc.createdAt}`;
      info.append(name, meta);
      const link = document.createElement("a"); link.href = `/api/documents/${encodeURIComponent(doc.id)}/download`; link.textContent = "Download";
      link.setAttribute("rel", "noopener");
      row.append(info, link); target.append(row);
    }
  } catch (e) { message(e.message, "error"); }
}
async function loadAudit() {
  if (!currentUser || currentUser.role !== "admin") return;
  try {
    const data = await api("/api/audit"); const target = $("audit"); target.replaceChildren();
    for (const log of data.logs) {
      const row = document.createElement("div"); row.className = "log";
      const line = document.createElement("strong");
      line.textContent = `${log.action} · ${log.outcome}`;
      const detail = document.createElement("small");
      detail.textContent = `${log.created_at} · ${log.actor_name} · ${log.resource} · ${log.details || ""}`;
      row.append(line, detail); target.append(row);
    }
    if (!data.logs.length) target.textContent = "No audit events yet.";
  } catch (e) { message(e.message, "error"); }
}
$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const mode = event.submitter?.dataset.mode || "login";
  const form = new FormData(event.currentTarget);
  try {
    const user = await api(`/api/${mode}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(Object.fromEntries(form.entries())) });
    showSignedIn(user.user); message(user.message || "Welcome back.", "success");
  } catch (e) { message(e.message, "error"); }
});
$("logout").addEventListener("click", async () => {
  try { await api("/api/logout", {method:"POST"}); showSignedOut(); message("Logged out.", "success"); }
  catch (e) { message(e.message, "error"); }
});
$("uploadForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const result = await api("/api/documents", {method:"POST", body:new FormData(event.currentTarget)});
    message(result.message, "success"); event.currentTarget.reset(); loadDocuments();
  } catch (e) { message(e.message, "error"); }
});
$("permissionForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    const result = await api(`/api/documents/${encodeURIComponent(form.documentId)}/permissions`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username:form.username,canRead:form.canRead})
    });
    message(result.message, "success"); loadDocuments(); loadAudit();
  } catch (e) { message(e.message, "error"); }
});
$("refreshAudit").addEventListener("click", loadAudit);
api("/api/me").then(data => data.user ? showSignedIn(data.user) : showSignedOut()).catch(showSignedOut);