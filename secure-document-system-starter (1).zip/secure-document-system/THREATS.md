# Threat model

## Assets
- Uploaded document contents.
- User accounts and password hashes.
- Role assignments and per-document permissions.
- Audit events and session cookies.

## Trust boundaries
- Browser to Express server.
- Authenticated user to server-side authorization checks.
- Express process to SQLite database and upload directory.
- Deployment environment variables and persistent storage.

## Threats and mitigations
1. **Unauthenticated user requests a document** — download route requires a session and records denied attempts.
2. **Viewer tries to upload** — upload endpoint checks role on the server, not only in the UI.
3. **User guesses another document ID** — download permission is checked for every request; IDs are not treated as authorization.
4. **User tries to download a document without permission** — server checks admin/uploader/explicit grant before sending file.
5. **Password database exposure** — passwords are hashed with bcrypt; never store plaintext passwords.
6. **Session theft through client-side script** — HttpOnly and SameSite cookies plus Helmet; production cookie uses Secure.
7. **Oversized or unexpected upload** — 5 MB cap and file MIME allowlist; file signatures and malware scanning remain improvements.
8. **Cross-site request forgery** — SameSite cookie helps but is not a complete CSRF defense. Add CSRF token or Origin validation before production.
9. **Audit log tampering** — events are stored in SQLite; a database administrator can alter them. External append-only logging is a future improvement.
10. **Data loss on host restart** — SQLite and uploads need persistent disk storage on deployment.

## Tests to perform before submission
- Signed-out visitor calls `/api/documents` and `/api/audit`.
- Viewer tries `POST /api/documents`.
- Viewer tries `POST /api/documents/1/permissions`.
- User A uploads a file; user B tries to download its ID without permission.
- Admin grants user B read permission; user B downloads it; admin revokes permission; user B is denied.
- Check that denied actions appear in the audit log.

Record actual test results here after running them. Do not claim a test passed until you ran it.
