const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("Set SESSION_SECRET to a random value of at least 32 characters.");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(dataDir, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const db = new sqlite3.Database(path.join(dataDir, "app.sqlite"));

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(express.json({ limit: "20kb" }));
app.use(session({
  name: "sds.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 4
  }
}));

function run(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (err) {
    if (err) reject(err); else resolve({ id: this.lastID, changes: this.changes });
  }));
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
}
async function init() {
  await run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','editor','viewer')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
  await run(`CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size INTEGER NOT NULL,
    uploaded_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(uploaded_by) REFERENCES users(id)
  )`);
  await run(`CREATE TABLE IF NOT EXISTS document_permissions (
    document_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    can_read INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(document_id, user_id),
    FOREIGN KEY(document_id) REFERENCES documents(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);
  await run(`CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id INTEGER,
    actor_name TEXT,
    action TEXT NOT NULL,
    resource TEXT,
    outcome TEXT NOT NULL,
    details TEXT,
    ip_address TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
}
async function audit(req, action, resource, outcome, details = "") {
  try {
    await run(
      `INSERT INTO audit_logs(actor_id, actor_name, action, resource, outcome, details, ip_address)
       VALUES(?,?,?,?,?,?,?)`,
      [req.session.user?.id || null, req.session.user?.username || "anonymous",
       action, resource || "", outcome, String(details).slice(0, 500),
       String(req.ip || "").slice(0, 80)]
    );
  } catch (e) { console.error("Audit write failed:", e.message); }
}
function requireAuth(req, res, next) {
  if (!req.session.user) {
    audit(req, "AUTH_REQUIRED", req.path, "DENIED", "Authentication required");
    return res.status(401).json({ error: "Please log in first." });
  }
  next();
}
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session.user || !roles.includes(req.session.user.role)) {
      audit(req, "ROLE_CHECK", req.path, "DENIED", `Required role: ${roles.join("/")}`);
      return res.status(req.session.user ? 403 : 401).json({ error: "You are not allowed to do this." });
    }
    next();
  };
}
async function canReadDocument(req, doc) {
  const user = req.session.user;
  if (!user || !doc) return false;
  if (user.role === "admin" || doc.uploaded_by === user.id) return true;
  const permission = await get(
    "SELECT can_read FROM document_permissions WHERE document_id=? AND user_id=?",
    [doc.id, user.id]
  );
  return Boolean(permission && permission.can_read === 1);
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, _file, cb) => cb(null, crypto.randomUUID())
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set(["application/pdf", "text/plain", "image/png", "image/jpeg"]);
    cb(null, allowed.has(file.mimetype));
  }
});

app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use("/static", express.static(path.join(__dirname, "public")));

app.post("/api/register", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");
    if (!/^[a-zA-Z0-9_-]{3,30}$/.test(username) || password.length < 12) {
      return res.status(400).json({ error: "Username must be 3–30 characters. Password must be at least 12 characters." });
    }
    const count = await get("SELECT COUNT(*) AS n FROM users");
    // First account becomes admin. Later public sign-ups are viewers only.
    const role = count.n === 0 ? "admin" : "viewer";
    const hash = await bcrypt.hash(password, 12);
    const result = await run("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)", [username, hash, role]);
    req.session.user = { id: result.id, username, role };
    await audit(req, "REGISTER", "user:" + username, "SUCCESS", "Created account with role " + role);
    res.json({ user: req.session.user, message: role === "admin" ? "First account created as admin." : "Account created as viewer." });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "That username is already taken." });
    console.error(e); res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");
    const user = await get("SELECT * FROM users WHERE username=?", [username]);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      await audit(req, "LOGIN", "user:" + username, "DENIED", "Invalid username or password");
      return res.status(401).json({ error: "Invalid username or password." });
    }
    req.session.regenerate(async (err) => {
      if (err) return res.status(500).json({ error: "Could not start session." });
      req.session.user = { id: user.id, username: user.username, role: user.role };
      await audit(req, "LOGIN", "user:" + username, "SUCCESS");
      res.json({ user: req.session.user });
    });
  } catch (e) { console.error(e); res.status(500).json({ error: "Login failed." }); }
});

app.post("/api/logout", requireAuth, async (req, res) => {
  await audit(req, "LOGOUT", "session", "SUCCESS");
  req.session.destroy(() => res.json({ message: "Logged out." }));
});
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.get("/api/documents", requireAuth, async (req, res) => {
  try {
    const docs = await all("SELECT * FROM documents ORDER BY id DESC");
    const visible = [];
    for (const doc of docs) if (await canReadDocument(req, doc)) visible.push({
      id: doc.id, name: doc.original_name, size: doc.size, uploadedBy: doc.uploaded_by, createdAt: doc.created_at
    });
    await audit(req, "LIST_DOCUMENTS", "documents", "SUCCESS", `Returned ${visible.length} permitted documents`);
    res.json({ documents: visible });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not list documents." }); }
});

app.post("/api/documents", requireAuth, requireRole("admin", "editor"), (req, res) => {
  upload.single("document")(req, res, async (err) => {
    if (err) {
      await audit(req, "UPLOAD_DOCUMENT", "documents", "DENIED", err.message);
      return res.status(400).json({ error: "Upload failed. Use PDF, TXT, PNG or JPG, up to 5 MB." });
    }
    if (!req.file) {
      await audit(req, "UPLOAD_DOCUMENT", "documents", "DENIED", "No allowed file selected");
      return res.status(400).json({ error: "Choose a PDF, TXT, PNG or JPG file (max 5 MB)." });
    }
    try {
      const result = await run(
        "INSERT INTO documents(original_name,stored_name,mime_type,size,uploaded_by) VALUES(?,?,?,?,?)",
        [path.basename(req.file.originalname).slice(0, 180), req.file.filename, req.file.mimetype, req.file.size, req.session.user.id]
      );
      await audit(req, "UPLOAD_DOCUMENT", "document:" + result.id, "SUCCESS", req.file.originalname);
      res.json({ message: "Document uploaded.", id: result.id });
    } catch (e) { fs.unlink(req.file.path, () => {}); console.error(e); res.status(500).json({ error: "Could not save document." }); }
  });
});

app.get("/api/documents/:id/download", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: "Invalid document ID." });
    const doc = await get("SELECT * FROM documents WHERE id=?", [id]);
    if (!doc || !(await canReadDocument(req, doc))) {
      await audit(req, "DOWNLOAD_DOCUMENT", "document:" + id, "DENIED", "Missing document or permission");
      return res.status(403).json({ error: "Access denied." });
    }
    const fullPath = path.join(uploadDir, doc.stored_name);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: "File not found." });
    await audit(req, "DOWNLOAD_DOCUMENT", "document:" + id, "SUCCESS", doc.original_name);
    res.download(fullPath, doc.original_name);
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not download document." }); }
});

app.post("/api/documents/:id/permissions", requireAuth, requireRole("admin"), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const username = String(req.body.username || "").trim();
    const canRead = req.body.canRead === true || req.body.canRead === "true";
    const doc = await get("SELECT id FROM documents WHERE id=?", [id]);
    const target = await get("SELECT id FROM users WHERE username=?", [username]);
    if (!doc || !target) return res.status(404).json({ error: "Document or user not found." });
    await run(
      `INSERT INTO document_permissions(document_id,user_id,can_read) VALUES(?,?,?)
       ON CONFLICT(document_id,user_id) DO UPDATE SET can_read=excluded.can_read`,
      [id, target.id, canRead ? 1 : 0]
    );
    await audit(req, "CHANGE_PERMISSION", "document:" + id, "SUCCESS", `username=${username}; canRead=${canRead}`);
    res.json({ message: "Permission updated." });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not update permission." }); }
});

app.get("/api/audit", requireAuth, requireRole("admin"), async (req, res) => {
  try {
    const logs = await all("SELECT id,actor_name,action,resource,outcome,details,ip_address,created_at FROM audit_logs ORDER BY id DESC LIMIT 200");
    res.json({ logs });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not read audit log." }); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

init().then(() => app.listen(PORT, () => console.log(`Secure Document System listening on ${PORT}`)))
  .catch(err => { console.error("Database setup failed:", err); process.exit(1); });
