# Secure Document Access and Audit Management System

A starter full-stack application demonstrating server-side role checks, document permissions, and audit logging.

## Features
- Account creation and login with bcrypt password hashing.
- First registered user becomes `admin`; subsequent sign-ups become `viewer`.
- `admin` and `editor` can upload allowed files; `viewer` cannot.
- Only admins, the uploader, or users with an explicit read permission can download a document.
- Admin-only permission management and audit-log viewing.
- SQLite database and server-side sessions.
- Upload allowlist and 5 MB file size limit.

## Run locally
Requires Node.js 20 or newer.

1. Install dependencies: `npm install`
2. Set a session secret (at least 32 characters).
   - macOS/Linux: `export SESSION_SECRET="$(openssl rand -hex 32)"`
   - PowerShell: `$env:SESSION_SECRET = "replace-with-a-random-secret-of-at-least-32-characters"`
3. Start: `npm start`
4. Open `http://localhost:3000`
5. Create the first account. It becomes admin. Use a strong unique password.

## Deployment notes
This starter uses local SQLite and local file storage. A hosting service must provide persistent disk storage for `data/`, or uploaded files and database records may be lost on redeploy/restart. Set `SESSION_SECRET` as a deployment environment variable and set `NODE_ENV=production` so cookies are secure over HTTPS. Never commit secrets, database files, or real private documents.

## Important limitations to address before production
- Public registration is enabled; later accounts become viewers. For a real deployment, consider invitation-only account creation.
- Add CSRF protection or strict Origin validation for state-changing routes before production use.
- Add malware scanning, stronger content-type validation by inspecting file signatures, rate limiting, and backup/restore procedures.
- Audit logs are stored in SQLite and are not tamper-proof against a server/database administrator.
- This is a starter implementation, not a security certification. Test every role and direct API route before submission.
