# AI/tool use log

Keep this file honest. Add dated entries while you work. For each entry include the actual prompt, what the tool produced, what was wrong or incomplete, what you changed yourself, and the related commit link.

## Entry 1 — YYYY-MM-DD
- Tool:
- Prompt used:
- Output produced:
- What was wrong/incomplete:
- What I changed or verified myself:
- Commit link:

## Entry 2 — YYYY-MM-DD (authorization/access control)
- Tool:
- Prompt used:
- Output produced:
- What was wrong/incomplete:
- What I changed or verified myself:
- Commit link:

## Entry 3 — YYYY-MM-DD
- Tool:
- Prompt used:
- Output produced:
- What was wrong/incomplete:
- What I changed or verified myself:
- Commit link:

## Entry 4 — YYYY-MM-DD (authorization/access control or audit trail)
- Tool:
- Prompt used:
- Output produced:
- What was wrong/incomplete:
- What I changed or verified myself:
- Commit link:

## Entry 5 — YYYY-MM-DD
- Tool:
- Prompt used:
- Output produced:
- What was wrong/incomplete:
- What I changed or verified myself:
- Commit link:
